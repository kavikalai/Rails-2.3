require 'jquery/datetimepicker/rails/version'

module Jquery
  module Datetimepicker
    module Rails
      class Engine < ::Rails::Engine

      end
    end
  end
end
