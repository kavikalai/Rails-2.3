module Jquery
  module Datetimepicker
    module Rails
      VERSION = '2.4.1.0'
    end
  end
end
